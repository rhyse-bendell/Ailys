﻿# Ailys
Local research assistant (GUI) with an approval-gated ""artificial_cognition"" brain.
See ARCHITECTURE.md for layout, and /tasks for feature modules.
